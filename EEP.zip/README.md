# Employee_Examination_Portal
A MERN Stack-based quiz platform that facilitates quiz administrators to create, manage and evaluate quizzes, and provides a platform for participants to appear quizzes in a clean, minimalistic view.
