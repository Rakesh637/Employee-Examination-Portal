import React from 'react'

const TableData = () => {
  return (
    <div>TableData</div>
  )
}

export default TableData