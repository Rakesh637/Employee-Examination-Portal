import React from 'react'
import SideBar from '../SideBarNav/SideBar';

export default function Generalsettings() {
  return (
  <>
    <SideBar/>
  </>
  )
}
