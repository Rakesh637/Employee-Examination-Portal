import React from 'react'
import SideBar from '../SideBarNav/SideBar';
function Groups() {
  return (
    <div>
      <SideBar/>
    </div>
  )
}

export default Groups