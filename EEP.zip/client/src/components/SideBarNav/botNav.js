import React from 'react'

const botNav = () => {
  return (
    <p style={{
        color :'white'
    }}>
        Logged in as : <br></br> Admin
    </p>
  )
}

export default botNav