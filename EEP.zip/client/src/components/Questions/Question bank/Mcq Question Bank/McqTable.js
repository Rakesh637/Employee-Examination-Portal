import React from 'react'

const McqTable = ({sortedData}) => {
  return (
    <div>McqTable</div>
  )
}

export default McqTable